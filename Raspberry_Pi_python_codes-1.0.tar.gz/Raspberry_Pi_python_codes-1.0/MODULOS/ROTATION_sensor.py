from pyfirmata2 import Arduino, util
from time import sleep

arduinoUNO = Arduino("COM4")
arduinoUNO.get_pin("a:0:i")
thread = util.Iterator(arduinoUNO)
thread.start()

sleep(1)

while True:
    arduiUNO.analog[0].enable_reporting()
    print(arduninoUNO.analog[0].read())
    sleep(0.5)
