from time import sleep

event = [4,9,5,6,8]
print("event = ", event)

sleep(1)

nums = list(filter(lambda n : n%2 == 0, event))
print("\nnums = ", nums)

sleep(1)

nums2 = list(filter(lambda m : m%2 == 1, event))
print("\nnums2 = ", nums2)
