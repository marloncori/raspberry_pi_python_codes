from pyfirmata2 import Arduino, util
from time import sleep

uno = Arduino("COM9")
it = util.Iterator(uno)
it.start()

LDR = uno.get_pin("a:0:i")

while True:
    value = LDR.read()
    print(value)
