import RPi.GPIO as Raspberry
from time import sleep

Raspberry.setwarnings(False)
Raspberry.setmode(Raspberry.BCM)

trig = 17
echo = 27
led = 22

mt1A = 16
mt1B = 12
mt2A = 21
mt2B = 20

Raspberry.setup(trig, Raspberry.OUT)
Raspberry.setup(echo, Raspberry.IN)
Raspberry.setup(led, Raspberry.OUT)

Raspberry.setup(mt1A, Raspberry.OUT)
Raspberry.setup(mt1B, Raspberry.OUT)
Raspberry.setup(mt2A, Raspberry.OUT)
Raspberry.setup(mt2B, Raspberry.OUT)

Raspberry.output(led, True)

sleep(5)

def stop():
    print("Stop")
    Raspberry.output(mt1A, 0)
    Raspberry.output(mt1B, 0)
    Raspberry.output(mt2A, 0)
    Raspberry.output(mt2B, 0)

def forward():
    print("Forward")
    Raspberry.output(mt1A, 1)
    Raspberry.output(mt1B, 0)
    Raspberry.output(mt2A, 1)
    Raspberry.output(mt2B, 0)

def backward():
    print("Backward")
    Raspberry.output(mt1A, 0)
    Raspberry.output(mt1B, 1)
    Raspberry.output(mt2A, 0)
    Raspberry.output(mt2B, 1)

def right():
    print("Turn right")
    Raspberry.output(mt1A, 1)
    Raspberry.output(mt1B, 0)
    Raspberry.output(mt2A, 0)
    Raspberry.output(mt2B, 0)

def left():
    print("Turn left")
    Raspberry.output(mt1A, 0)
    Raspberry.output(mt1B, 0)
    Raspberry.output(mt2A, 1)
    Raspberry.output(mt2B, 0)

def getDistance():
    i = 0
    avgDist = 0
    for i in range(5):
        Raspberry.output(trig, False)
        sleep(0.000002)
        Raspberry.output(trig, True)
        sleep(0.00001)
        Raspberry.output(trig, False)

        while Raspberry.output(echo) == 0:
            Raspberry.output(led, False)
            pulse_start = time.time()

        while Raspberry.output(echo) == 1:
            Raspberry.output(led, True)
            pulse_end = time.time()
            duration = pulse_end - pulse_start

            distance = duration * 17150 # or distance = duration * 34300/2
            distance = round(distance,2)
            avgDist = avgDist + distance
            avgDist = avgDist/5
            print(avgDist)
    return avgDist

stop()
count = 0

while True:
    getDistance()
    flag = 0
    if avgDistance < 15:
        count+=1
        stop()
        sleep(1)
        back()
        sleep(1.5)
        if (count%3 == 1 && flag == 0):
            right()
            flag = 1
        else:
            left()
            flag = 0
            sleep(1.5)
            stop()
            sleep(1)
    else:
        forward()
        flag = 0
