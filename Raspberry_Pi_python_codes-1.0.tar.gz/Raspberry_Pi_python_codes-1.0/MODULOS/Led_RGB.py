from pyfirmata2 import Arduino, util
from time import sleep

board = Arduino("COM4")
it = util.Iterator(board)
it.start()

red = board.get_pin("d:11:o")
green = board.get_pin("d:10:o")
blue = board.get_pin("d:9:o")

def ledRed():
    red.write(1)
    green.write(0)
    blue.write(0)
    
def ledGreen():
    red.write(0)
    green.write(1)
    blue.write(0)
    
def ledBlue():
    red.write(0)
    green.write(0)
    blue.write(1)

def white():
    red.write(1)
    green.write(1)
    blue.write(1)

while True:
    ledRed()
    sleep(1)
    ledGreen()
    sleep(1)
    ledBlue()
    sleep(1)
    white()
    sleep(1)
    
