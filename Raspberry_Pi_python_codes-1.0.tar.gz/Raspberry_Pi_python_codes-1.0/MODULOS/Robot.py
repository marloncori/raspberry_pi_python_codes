#classe com funcoes encapsuladas com __

class Robot():
    def __init__(self, lig, distR, distL, distF, obs):
        self.ligado = lig
        self.distanciaR = distR
        self.distanciaL = distL
        self.distanciaF = distF
        self.obstaculo = obs

    def praFrente(self):
        if(self.ligado):
            self.__analisaDistF()
            self.__barreira()
            if self.distanciaF > 20 and self.obstaculo == False:
                print("El robot esta caminando adelante")
            else:
                print("El robot ha desviado de la barrera")
        else:
            print("El robot esta delisgado.")

    def virarDirEsq(self):
        if(self.ligado):
            self.__analisaDistR()
            self.__analisaDistL()
        
            if self.distanciaR > self.distanciaL:
                print("Robo esta virando pra direita")
            else:
                print("Robo esta virando pra esquerda")
        else:
            print("Tente ligar o robo para que ele se mova!")
            
    def __analisaDistF(self):
        print("Vamos analisar a distancia diante do robo")

    def __analisaDistR(self):
        print("\nVamos analisar a distancia a direita do robo")

    def __analisaDistL(self):
        print("Vamos analisar tambem a distancia a esquerda do robo")

    def __barreira(self):
        print("Y vamos a chequear tambien si hay algun obstaculo")

meuRobo = Robot(True, 20, 12, 3, True)
meuRobo.praFrente()
