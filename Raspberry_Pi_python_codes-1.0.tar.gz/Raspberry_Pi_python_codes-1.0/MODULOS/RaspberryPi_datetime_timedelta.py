import datetime

a = datetime.datetime(100,1,1,6,9,59)
b = a + datetime.timedelta(0,6)  #o tempo em parentesis eh de delay em segundos

print(a.time())
print(b.time())

#results in...
