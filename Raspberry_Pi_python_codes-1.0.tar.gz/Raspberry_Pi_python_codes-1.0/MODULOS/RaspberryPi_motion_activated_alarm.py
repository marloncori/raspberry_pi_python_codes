#motion activated alarm system

import csv #it is a file format
from pathlib import Path #for me to able to access the csv file with timestamps
from datetime import time
from gpiozero import LED, Buzzer, MotionSensor
from signal import pause

led = LED(14) # RaspberryPi GPIO
buzzer = Buzzer(15)
motionSensor = MotionSensor(4)

output_csvPath = Path("detected_motion.csv")
motion = {
    "start_time" = None,
    "end_time" = None,
    }

def writeToCsv():
    firstWrite = not output_csvPath.is_file()

    with open(output_csvPath, "a") as file:
        fieldNames = motion.keys()
        writer = csv.DictWriter(file, fieldNames)
        if firstWrite:
            writer.writeheader()
        writer.writerow(motion)

def start_motion():
    led.blink(0.5, 0.5)
    buzzer.beep(0.5, 0.5)
    motion["start_time"] = datetime.now()
    print("Motion detected")

def end_motion():
    if motion["start_time"]:
        led.off()
        buzzer.off()
        motion["end_time"] = datetime.now()
        writeToCsv()
        motion["start_time"] = None
        motion["end_time"] = None
    print("Motion ended")

    print("Reading sensor...")
    motionSensor.wait_for_no_motion()
    print("Sensor ready")

    motionSensor.when_motion = start_motion
    motionSensor.when_no_motion = end_motion

    pause()
