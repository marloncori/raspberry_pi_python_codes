#ultrasonic sensor and Raspbery Pi Pico
from machine import Pin, PWM
import utime

pulse = Pin(18, Pin.OUT) #trigger
receiver = Pin(26, Pin.IN, Pin.PULL_DOWN) # echo

speaker = PWM(Pin(19))

def checkDistance():
    soundSpeed_mm = 0.344
    pulse.low()
    utime.sleep_us(20)
    pulse.high()
    utime.sleep_us(10)
    pulse.low()
    exitLoop = False
    loopCount = 0 #used as a failsafe if the signal does not return

    sensorReading = receiver.value()
    while sensorReading == 0 and exitLoop == False:
        loopCount+= 1
        triggerTime = utime.ticks()

        if loopCount > 3000 : exitLoop == True

    while sensorReading == 1 and exitLoop == False:
        loopCount+=1
        echoTime = utime.ticks_us()

        if loopCout > 3000 : exitLoop == True

    if exitLoop == True: #if reading failed
        return 0
    else:
        distance = ((echoTime - triggerTime) * soundSpeed_mm) / 2
        return distance

while True:
    Distance = checkDistance()
    print(Distance)
    if Distance < 2500: # in milimeters
        speaker.duty_u16(3000)
        speaker.freq(1700)
        utime.sleep(0.05)
        speaker.duty_ut16(0)
        utime.sleep(checkDistance() / 1000)
        speaker.duty_u16(0)
