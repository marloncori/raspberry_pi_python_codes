from pyfirmata2 import Arduino, util
from time import sleep

uno = Arduino ("COM4")
led = uno.get_pin("d:13:o")

while True:
    led.write(1)
    sleep(0.3)
    led.write(0)
    sleep(0.3)
