#touch switch with RaspberryPi - digital touch sensor
import RPi.GPIO as RaspberryPi
from time import sleep
import os

buzzer = 14
touchSensor = 26
relay_in1 = 13
relay_in2 = 19

def init():
    RaspberryPi.setwarnings(false)
    RaspberryPi.setmode(RaspberryPi.BCM)
    RaspberryPi.setup(buzzer,RaspberryPi.OUT)
    RaspberryPi.setup(relay_in1,RaspberryPi.OUT)
    RaspberryPi.setup(relay_in2,RaspberryPi.OUT)
    RaspberryPi.setup(touchSensor,RaspberryPi.IN,pull_up_down=RaspberryPi.PUD_UP)
    pass

def buzzerON():
    RaspberryPi.output(buzzer,RaspberryPi.LOW)
    sleep(0.2)
    RaspberryPi.output(buzzer,RaspberryPi.HIGH)
    sleep(0.2)
    pass

def buzzerOFF():
    RaspberryPi.output(buzzer,RaspberryPi.HIGH)
    pass

def relayON():
    RaspberryPi.output(delay_in1,RaspberryPi.LOW)
    RaspberryPi.output(delay_in2,RaspberryPi.LOW)

def relayOFF():
    RaspberryPi.output(relay_in1,RaspberryPi.HIGH)
    RaspberryPi.output(relay_in2,RaspberryPi.HIGH)

touchStatus = False

def read_touchSensor()
    global touchStatus
    if(RaspberryPi.input(touchSensor) == True):
        touchStatus = not touchStatus
        if touchStatus:
            print("Turn on relay")
    print("\n")
            buzzerON()
            relayON()
        else:
            print("Turn off relay")
    print("\n")
            buzzerOFF()
            relayOFF()
    pass

def main():
    print(".............System initalizing....")
    init()
    buzzerOFF()
    relayOFF()
    print("..............Ok....")
    print("........ Please touch the pad")
    print("\n")
    while True:
        read_touchSensor()

if __name__ == '__main__':
    try:
        main()
        pass
    except KeyboardInterrupt:
        pass
    pass
RaspberryPi.cleanup()

    
