import turtle

trtl = turtle.Turtle()    #making a turtle object of Turtle class for drawing
screen=turtle.Screen()    #making a canvas for drawing
screen.setup(400,300)    #choosing the screen size
screen.bgcolor('yellow')    #making canvas black
trtl.pencolor('red')    #making colour of the pen red
trtl.pensize(5)    #choosing the size of pen nib
trtl.speed(1)    #choosing the speed of drawing
trtl.shape('turtle')   #choosing the shape of pen nib
trtl.forward(100)    #top line
trtl.right(90)
trtl.forward(100)    # right vertical line
trtl.right(90)
trtl.forward(100)   # bottom line
trtl.right(90)
trtl.forward(100)   # left vertical line
# information printing
trtl.penup()
trtl.setpos(-120,100)
trtl.pendown()
trtl.pencolor('orange')
trtl.write('red color', font=("Arial", 16, "bold"))
trtl.penup()
trtl.ht()   

trtl2 = turtle.Turtle()    #making a turtle object of Turtle class for drawing
screen=turtle.Screen()    #making a canvas for drawing
screen.setup(400,300)    #choosing the screen size
screen.bgcolor('cyan')    #making canvas black
trtl2.pencolor('white')    #making colour of the pen red
trtl2.pensize(5)    #choosing the size of pen nib
trtl2.speed(1)    #choosing the speed of drawing
trtl2.shape('turtle')   #choosing the shape of pen nib
trtl2.forward(50)    #top line
trtl2.right(120)
trtl2.forward(40)    # right vertical line
trtl2.right(100)
trtl2.forward(30)   # bottom line
trtl2.right(90)
trtl.forward(10)   # left vertical line
# information printing
trtl.penup()
trtl.setpos(-10,100)
trtl.pendown()
trtl.pencolor('green')
trtl.write('white triangle', font=("Arial", 16, "bold"))
trtl.penup()
trtl.ht()   
