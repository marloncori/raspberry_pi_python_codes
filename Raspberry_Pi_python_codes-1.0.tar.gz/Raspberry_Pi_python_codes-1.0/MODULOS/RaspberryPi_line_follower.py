import RPi.GPIO as RaspberryPi
from time import sleep

RaspberryPi.setwarnings(False) #it tells Pi to ignore warnings from GPIOS
                                #which may be busy while trying to do sth else
RaspberryPi.setmode(RaspberryPi.BCM) # I am telling I can refer to the GPIOs anyway
RaspberryPi.setup(2,RaspberryPi.IN) #GPIO2 - left IR sensor as input
RaspberryPi.setup(3,RaspberryPi.IN) #GPIO3 - right IR sensor as input

RaspberryPi.setup(4,RaspberryPi.OUT) #right motor, terminal A
RaspberryPi.setup(14,RaspberryPi.OUT) #right motor, terminal B

RaspberryPi.setup(17,RaspberryPi.OUT) #gpio17 left motor, terminal A
RaspberryPi.setup(18,RaspberryPi.OUT) #gpio18 left motor, terminal B

def moveForward():
    RaspberryPi.ouput(4,True) #right motor A
    RaspberryPi.output(14,False) # right motor B
    RaspberryPi.output(17,True) # left motor A
    RaspberryPi.output(18,False) #left motor B
    
def moveBackward():
    RaspberryPi.ouput(4,False) #right motor A
    RaspberryPi.output(14,True) # right motor B
    RaspberryPi.output(17,False) # left motor A
    RaspberryPi.output(18,True) #left motor B
    
def turnRight():
    RaspberryPi.ouput(4,True) #right motor A
    RaspberryPi.output(14,True) # right motor B
    RaspberryPi.output(17,True) # left motor A
    RaspberryPi.output(18,False) #left motor B
    
def turnLeft():
    RaspberryPi.ouput(4,True) #right motor A
    RaspberryPi.output(14,False) # right motor B
    RaspberryPi.output(17,True) # left motor A
    RaspberryPi.output(18,True) #left motor B
    
def stop():
    RaspberryPi.ouput(4,False) #right motor A+
    RaspberryPi.output(14,False) # right motor B-
    RaspberryPi.output(17,False) # left motor A+
    RaspberryPi.output(18,False) #left motor B-
    
while True: #or while 1:
    leftIR_sensor_reading = RaspberryPi.input(2)
    rightIR_sensor_reading = RaspberryPi.input(3)
    
    if(leftIR_sensor_reading == True and rightIR_sensor_reading == True):
        moveForward()
        
    elif(leftIR_sensor_reading == False and rightIR_sensor_reading == True):
        turnRight()
        
    elif(leftIR_sensor_reading == True and rightIR_sensor_reading == False):
        turnLeft()

    else:
        stop()
    
