from pyfirmata2 import Arduino, util
from time import sleep

UNO = Arduino("COM4")
it = util.Iterator(UNO)
it.start()

clk = UNO.get_pin("d:2:i")
dt = UNO.get_pin("d:3:i")
sw = UNO.get_pin("d:4:i")

def encoder():
    oldA = 1
    oldB = 1
    result = 0
    newA = clk.read()
    newB = dt.read()

    if newA != oldA or newB != oldB:
        if oldA == 1 and newA == 0:
            result = (oldB*2)-1
    oldA = newA
    oldB = newB
    return result

encoderVal = 0
change = 0

while True:
    sw.write(1)
    change = encoder()
    encoderVal = encoderVal + change

    if sw.read() == 0:
        enconderVal = 0

    print(encoderVal)
    sleep(1)
