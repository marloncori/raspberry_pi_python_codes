
class Computer(object):

    memory = "500 GB"

    def __init__(self, preco, marca):
        self.price = preco
        self.bran = marca

    def showInfo(self):
        print("O pc custa ", self.preco, "e eh da marca ", self.marca)

    @classmethod 
    def showMemory(cls):
        print("\nE o memoria que o PC tem eh de " + cls.memory)

pc = Computer(1500, "Asus")
pc.showInfo
Computer.showMemory()  #essa funcao nao tem como imprimir.  
