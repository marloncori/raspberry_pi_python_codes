import RPi.GPIO as RaspberryPi
from time import sleep

RaspberryPi.setmode(RaspberryPi.BCM) # istead of (RaspberryPi.BOARD)
RaspberryPi.setwarnings(False)

pressurePad = 4
RaspberryPi.setup(pressurePad,RaspberryPi.IN)

#initialise a previous input variable
prevInput = 0

try:
    while True_
        #take a reading
        reading = RaspberryPi.input(pressurePad)
        #if last reading was low and this is high, alert us
        if((not prevInput) and reading):
            print("Under pressure")
        #update previous input
        prevInput = reading
        #slight pause
        sleep(0.10)
except KeyboardInterrupt:
    pass
finally:
    RaspberryPi.cleanup()
