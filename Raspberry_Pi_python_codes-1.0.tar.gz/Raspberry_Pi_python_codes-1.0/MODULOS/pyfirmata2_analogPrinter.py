from pyfirmata2 import Arduino
from time import sleep

PORT = Arduino.AUTODETECT

class AnalogPrinter:
    def __init__(self):
        #sampling rate at 10HZ
        self.samplingRate = 10
        self.timestamp = 0
        self.uno = Arduino(PORT)

    def start(self):
        self.uno.analog[0].register_callback(self.myPrintCallback)
        self.uno.samplingOn(1000 / self.samplingRate)
        self.uno.analog[0].enable_reporting()

    def myPrintCallback(self, data):
        print("%f,%f" % (self.timestamp, data))
        self.timestamp += (1/ self.samplingRate)

    def stop(self):
        self.uno.samplingOff()
        self.uno.exit()

print("Let us print data from Arduino analogue pins for 10 secs.")

analogPrinter = AnalogPrinter()

analogPrinter.start()
#I could do something else here with the read data

sleep(10)

analogPrinter.stop()

print("Finished")
