
class Carro():
    def __init__(self,name,power):
        self.nome = name
        self.potencia = power
        self.velMax = int(power)*2
        self.ligado = False

    def ligar(self):
        self.ligado = True
        print("O carro agora estah ligado")

    def desligar(self):
        self.ligado = False
        print("O carro agora estah desligado.")

    def info(self):
        print("Nome........:" + self.nome)
        print("Potencia....:" + str(self.potencia))
        print("Velocidade..:" + str(self.velMax))
        print("Ligado......:" + ("Sim" if self.ligado == True else "Nao"))
