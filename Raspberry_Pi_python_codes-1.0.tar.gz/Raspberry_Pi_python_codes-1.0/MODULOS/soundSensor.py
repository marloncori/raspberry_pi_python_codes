
class soundSensor():
    def __init__(self,pin,state):
        self.pin=pin
        self.state=state

    def digitalWrite(self):
            print("digitalWrite(",self.pin, ",",self.state,")")

    def info(self):
            print(self.pin, ",", self.state)
        
    def digitalRead(self,value):
        self.value=value
        if self.value == 1:
            print("digitalRead(", self.pin,",HIGH)")
            print("O sensor nao identifica nenhum ruido")

        if self.value == 0:
            print("digitalRead(", self.pin,",LOW)")
            print("O sensor identificou ruidos")
