from machine import Pin
from machine import PWM
from time import sleep

pwm_led = PWM(Pin(2))

pwm.freq(100)

while 1:
    for brightness in range(0,1023,100):
        pwm_led.duty(brightness)
        print(brightness)
        sleep(0.1)

    for brightness in range(1023,0,-100):
        pwm_led.duty(brightness)
        print(brightness)
        sleep(0.1)
