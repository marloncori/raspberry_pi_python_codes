#SHARP sensor GP2YA41SK0F model 4-30 cm
#distance_cm = 12.08 * pow(volt, -1.058)

#SHARP sensor GP2Y0A21YK0F model 10-80 cm
#distance_cm = 29.988 * pow(volt, -1.173)

#SHARP sensor GP2Y0A02YK0F model 20-150 cm
#distace_cm = 60.374 * pow(volt, -1.16)

sharp_sensor1 = 17
sharp_sensor2 = 19
sharp_sensor3 = 22
sharp_sensor4 = 30

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(sharp_sensor1, GPIO.IN)
GPIO.input(sharp_sensor1, GPIO.LOW)

GPIO.setup(sharp_sensor2, GPIO.IN)
GPIO.input(sharp_sensor2, GPIO.LOW)

GPIO.setup(sharp_sensor3, GPIO.IN)
GPIO.input(sharp_sensor3, GPIO.LOW)

GPIO.setup(sharp_sensor4, GPIO.IN)
GPIO.input(sharp_sensor4, GPIO.LOW)

def calculoVolts(valorPorta):
    volts = (float(valorPorta) * 5 /1024)
    return volts #5 volts, 1024 sao valores analogicos

def calculoSharp1(volt):
    distance = 12.08 * pow(volt, -1.058)
    return distance

def calculoSharp2(volt):
    distance = 29.988 * pow(volt, -1.173)
    return distance

def calculoSharp3(volt):
    distance = 60.374 * pow(volt, -1.16)
    return distance

def calculoSharp4(volt)
    distance = 1 / ((volt - 1125) / 137500)
    return distance

While True: 
    valorSensor1 = sharp_sensor1.value() # sensor reading
    valorVolts1 = calculoVolts(valorSensor1) # reading to volt conversion

    valorSensor2 = sharp_sensor2.value() # sensor reading
    valorVolts2 = calculoVolts(valorSensor2) # reading to volt conversion

    valorSensor3 = sharp_sensor3.value() # sensor reading
    valorVolts3 = calculoVolts(valorSensor3) # reading to volt conversion

    valorSensor4 = sharp_sensor4.value() # sensor reading
    valorVolts4 = calculoVolts(valorSensor4) # reading to volt conversion
    
    calculoSharp1(valorVolts1)
    calculoSharp2(valorVolts2)
    calculoSharp3(valorVolts3)
    calculoSharp4(valorVolts4)
