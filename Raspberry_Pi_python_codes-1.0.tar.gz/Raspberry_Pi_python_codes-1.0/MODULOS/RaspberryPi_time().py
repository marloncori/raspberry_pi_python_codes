#millis() instead of delay (sleep) in Python

import time

prevTime = time.time()
while True:
    print("there is something in sight field")
    time.sleep(1)

    timeNow = time.time()
    if timeNow - prevTime > 30:
        print("Half minute over, nothing is seen")
        prevTime = time.time()
    
