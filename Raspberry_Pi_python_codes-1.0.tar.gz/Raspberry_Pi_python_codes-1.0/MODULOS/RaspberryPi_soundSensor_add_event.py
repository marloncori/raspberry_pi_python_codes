#sound sensor
import RPi.GPIO as RaspberryPi
from time import sleep

soundSensor = 17
RaspberryPi.setmode(RaspberryPi.BCM) #instead of (RaspberryPi.BOARD)

def feedback(soundSensor):
    if RaspberryPi.input(soundSensor):
        print("sound detected")
    else:
        print("No sound detected")

RaspberryPi.add_event_dected(soundSensor, RaspberryPi.BOTH, bouncetime=300)
#let us know when the PIN goes HIGH (True, 1) or LOW (False, 0)
RaspberryPi.add_event_callback(soundSensor, feedback)
#assign function to GPIO pin, run function on change

while True: #or While 1:
    sleep(1)
