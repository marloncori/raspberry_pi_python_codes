#Swap variables

c = 15
d = 63

print(c)
print(d)

c,d = d,c

print(c)
print(d)
