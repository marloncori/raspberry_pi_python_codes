from time import sleep

updateWeather = 30
updateAlarms = 10 # how to often to update

intervalWeather = time.time()
intervalAlarm = time.time() # initial timer

while True:
    timeNow = time.time()
    if timeNow - intervalWeather >= updateWeather:
            checkWeather()
            intervalWeather = time.time()

    if timeNow - intervalAlarm >= updateAlarm:
            checkAlarm()
            intervalAlarm = time.time()
