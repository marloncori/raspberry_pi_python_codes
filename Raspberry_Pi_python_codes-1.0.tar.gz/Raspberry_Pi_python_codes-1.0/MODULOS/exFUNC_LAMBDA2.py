from time import sleep

f = lambda x,y : x*y

result = f(5,6)
print("f = lambda(", result, ")")

sleep(0.5)

g = lambda x,y : x/y

resultado = g(100,50)
print("g = lambda(", resultado, ")")

sleep(0.5)
