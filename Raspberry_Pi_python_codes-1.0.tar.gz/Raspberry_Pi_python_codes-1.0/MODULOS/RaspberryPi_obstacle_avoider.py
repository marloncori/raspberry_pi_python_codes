import RPi.GPIO as RaspberryPi
from time import sleep, time()

RaspberryPi.setwarnings(False)
RaspberryPi.setmode(RaspberryPi.BCM)

trigger = 17
echo = 27
led = 22

rightMotor1A = 16
leftMotor1B = 12
rightMotor2A = 21
leftMotor2B = 20

RaspberryPi.setup(trigger,RaspberryPi.OUT)
RaspberryPi.setup(echo, RaspberryPi.IN)

RaspberryPi.setup(led,RaspberryPi.OUT)

RaspberryPi.setup(rightMotor1A,RaspberryPi.OUT)
RaspberryPi.setup(leftmotor1B,RaspberryPi.OUT)
RaspberryPi.setup(rightMotor2A,RaspberryPi.OUT)
RaspberryPi.setup(leftMotor2B,RaspberryPi.OUT)

RaspberryPi.output(led, 1) # ou RaspberryPi.output(led, True), o mesmo que HIGH

sleep(5)

def moveForward():
    RaspberryPi.ouput(rightMotor1A,True) #right motor A
    RaspberryPi.output(leftMotor1B,False) # right motor B
    RaspberryPi.output(rightMotor2A,True) # left motor A
    RaspberryPi.output(leftMotor2B,False) #left motor B
    
def moveBackward():
    RaspberryPi.ouput(rightMotor1A,False) #right motor A
    RaspberryPi.output(leftMotor1B,True) # right motor B
    RaspberryPi.output(rightMotor2A,False) # left motor A
    RaspberryPi.output(leftMotor2B,True) #left motor B
    
def turnRight():
RaspberryPi.ouput(rightMotor1A,True) #right motor A
    RaspberryPi.output(leftMotor1B,False) # right motor B
    RaspberryPi.output(rightMotor2A,False) # left motor A
    RaspberryPi.output(leftMotor2B,False) #left motor B
    
def turnLeft():
    RaspberryPi.ouput(rightMotor1A,False) #right motor A
    RaspberryPi.output(leftMotor1B,False) # right motor B
    RaspberryPi.output(rightMotor2A,True) # left motor A
    RaspberryPi.output(leftMotor2B,False) #left motor B
    
def stop():
    RaspberryPi.ouput(rightMotor1A,False) #right motor A
    RaspberryPi.output(leftMotor1B,False) # right motor B
    RaspberryPi.output(rightMotor2A,False) # left motor A
    RaspberryPi.output(leftMotor2B,False) #left motor B

stop()
count = 0

while True:
    i = 0
    avgDistance = 0
    for i in range(5):
        RaspberryPi.output(trigger,False)
        sleep(0.1)
        RaspberryPi.output(trigger,True)
        sleep(0.00001)
        RaspberryPi.output(trigger,False)

        while RaspberryPi.input(echo) == 0:
            RaspberryPi.output(led,False)

        pulse_start = time()

        while RaspberryPi.input(echo) == 1:
            RaspberryPi.output(led,True)

        pulse_end = time()

        pulse_duration = pulse_end - pulse_start
        distance = pulse_duration * 17150  # 17150 is the same as (34300/2), sound speed divided by two
        distance = round(distance,2)

        avgDistance+=distance
    avgDistance = avgDistance/5
    print(avgDistance)
    flag = 0

    if avgDistance < 15:
        count+=1
        stop()
        sleep(1)

        moveBackward()
        sleep(1.5)
        if count%3 == 1 and flag == 0:
            turnRight()
            flag = 1
        else:
            left()
            flag = 0
            sleep(1.5)
            stop()
            sleep(1)
    else:
        moveForward()
        flag = 0
        
        
