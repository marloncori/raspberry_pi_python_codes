from pyfirmata2 import Arduino, util
from time import sleep

board = Arduino("COM18")
it = util.Iterator(board)
it.start()

IR_sensor = board.get_pin("d:12:i")

while True:
    value = IR_sensor.read()
    print(value)
    if value == False
        print("No obstacle detected")
    elif value == True
        print("Obstacle detected")
