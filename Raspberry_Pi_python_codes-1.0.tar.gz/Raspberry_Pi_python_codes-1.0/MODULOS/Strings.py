
Str = "Oi, gente'"
dic = {"num":1, "num2":2}
lista = ("C++", "Python", "MatLab")
tupla = [20, 30, 40]

print("Metodos para uma string:")
print(dir(Str))
print("\n")

print("Metodos para uma tupla:")
print(dir(tupla))
print("\n")

print("Metodos para uma dicionario:")
print(dir(dic))
print("\n")

print("Metodos para uma lista:")
print(dir(lista))
print("\n")
