from pyfirmata2 import Arduino, util
from time import sleep

board = Arduino("COM8")
it = util.Iterator(board)
it.start()

def blinkLED(pin, message):
    print(message)
    board.digital[pin].write(1)
    sleep(1)
    borad.digital[pin].write(0)
    sleep(0)

pirPin = board.get_pin("d:7:i")
redPin = 12
greenPin = 13

while True:
    value = pirPin.read()
    while value is None:
        pass
    if value is True:
        blinkLED(redPin, "Motion detected!")
    else:
        blinkLED(greenPin, "No motion detected.")
        board.exit()
