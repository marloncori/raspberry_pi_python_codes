from time import sleep
import Adafruit_TCS34725
import smbus
import RPi.GPIO as GPIO
import turtle

tcs = Adafruit_TCS34725.TCS34725()
tcs.set_interrupt(False)

GPIO.setmode(GPIO.BOARD)

red_led = 32
green_led = 36
blue_led = 38

GPIO.setup(red_led, GPIO.OUT)
GPIO.setup(green_led, GPIO.OUT)
GPIO.setup(blue_led, GPIO.OUT)  # p.start(dc) duty cycle (0.0 <= dc <= 100)

pr = GPIO.PWM(red_led,50)  # channel (RPi pin), frequency 50 Hz
pg = GPIO.PWM(green_led,50)# channel (RPi pin), frequency 50 Hz
pb = GPIO.PWM(blue_led,50) # channel (RPi pin), frequency 50 Hz

    #there is also p.ChangeFrequency(freq) freq is the new frequency
    #p.ChangeDutyCycle(dc) where 0.0 <= dc <= 100, p.stop()

pr.start(20)
pg.start(20) # duty cycle of 20 percent
pb.start(20  #Duty cycle: A duty cycle is the fraction of one
              #period when a system or signal is active.
             #We typically express a duty cycle as a ratio or percentage.
             #A period is the time it takes for a signal to conclude
             #a full ON-OFF cycle.

i = 0
w = " " 

while i < 10:
    i += 1
    r, g, b, c = tcs.get_raw_date() # c stands for CLEAR color, no filter, white
    color_temp = Adafruit_TCS34725.calculate_color_temperature(r, g, b)
    lux = Adafruit_TCS34725.calculate_lux(r, g, b)
    print("Color: red={0} green={1} blue={2} clear={3}".format(r, g, b, c))
    sleep(1)
    if((r > b) and (r > g)):
        if(b < 5):
            pr.ChangeDutyCycle(80)
            pg.ChangeDutyCycle(1)
            pb.ChangeDutyCycle(1)
            w = "red"
            print("{} color has been detected".format(w))

        elif(r-g < 20 and r-b > 10 and r > 15):
            pr.ChangeDutyCycle(80)
            pg.ChangeDutyCycle(65)
            pb.ChangeDutyCycle(1)
            w = "yellow"
            print("{} color has been detected".format(w))

    elif((r < b) and (b > 5)):
        pr.ChangeDutyCycle(1)
        pg.ChangeDutyCycle(1)
        pb.ChangeDutyCycle(80)
        w = "blue"
        print("{} color has been detected".format(w))

    elif((r < g) and (b < g) and (g > 20)):
        if(b < 10):
            pr.ChangeDutyCycle(1)
            pg.ChangeDutyCycle(80)
            pb.ChangeDutyCycle(1)
            w = "green"
            print("{} color has been detected".format(w))

        elif(b > 10 and r-g < 6):
            pr.ChangeDutyCycle(60)
            pg.ChangeDutyCycle(5)
            pb.ChangeDutyCycle(70)
            w = "purple"
            print("{} color has been detected".format(w))

    elif((r > g) and (b > g) and (r > 45)):
        pr.ChangeDutyCycle(0)
        pg.ChangeDutyCycle(70)
        pb.ChangeDutyCycle(70)
        w = "cyan"
        print("{} color has been detected".format(w))

    elif((r > 100 and (b > 90) and (g > 100)):
        pr.ChangeDutyCycle(80)
        pg.ChangeDutyCycle(80)
        pb.ChangeDutyCycle(80)
        w = "white"
        print("{} color has been detected".format(w))

    elif((r < 25) and (b < 20) and (g < 20)):
        pr.ChangeDutyCycle(0)
        pg.ChangeDutyCycle(0)
        pb.ChangeDutyCycle(0)
        w = "black"
        print("{} color has been detected".format(w))

    else:
        pr.ChangeDutyCycle(20)
        pg.ChangeDutyCycle(20)
        pb.ChangeDutyCycle(20)
        print("No color has been detected")

sleep(9)
trtl = turtle.Turtle()    #making a turtle object of Turtle class for drawing
screen=turtle.Screen()    #making a canvas for drawing
screen.setup(400,300)    #choosing the screen size
screen.bgcolor('black')    #making canvas black
trtl.pencolor(w)    #making colour of the pen red
trtl.pensize(5)    #choosing the size of pen nib
trtl.speed(1)    #choosing the speed of drawing
trtl.shape('turtle')   #choosing the shape of pen nib
trtl.forward(100)    #top line
trtl.right(90)
trtl.forward(100)    # right vertical line
trtl.right(90)
trtl.forward(100)   # bottom line
trtl.right(90)
trtl.forward(100)   # left vertical line
# information printing
trtl.penup()
trtl.setpos(-120,100)
trtl.pendown()
trtl.pencolor(w)
trtl.write(w, font=("Arial", 16, "bold"))
trtl.penup()
trtl.ht()

# Print out color temperature.
#if color_temp is None:
  #  print('Too dark to determine color temperature!')
#else:
   # print('Color Temperature: {0} K'.format(color_temp))
#print('Luminosity: {0} lux'.format(lux))

tcs.set_interrupt(True)
tcs.disable()
pr.stop()
pg.stop()
pb.stop()
GPIO.clear()
