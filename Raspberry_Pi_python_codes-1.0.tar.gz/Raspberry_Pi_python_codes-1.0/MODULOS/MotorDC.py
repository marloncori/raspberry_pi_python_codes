
class MotorDC ():
    def __init__(self,pin1,pin2,speed):
        self.pin1=pin1
        self.pin2=pin2
        self.speed=speed
        
    def info(self):
        print("\n\tO motor estah conectado nas portas", self.pin1, "e", self.pin2)
        print("do Arduino e estah girando a uma velicade de", self.speed, "rpm.")

    def forward(self):
        print("\n\tMotor girando pra frente")
        
    def backward(self):
        print("\n\tMotor girando pra tras")
        
    def right(self):
        print("\n\tMotor virando pra direita")
        
    def left(self):
        print("\n\tMotor virando pra esquerda")
        
    def stop(self):
        print("\n\tMotor parando...")
