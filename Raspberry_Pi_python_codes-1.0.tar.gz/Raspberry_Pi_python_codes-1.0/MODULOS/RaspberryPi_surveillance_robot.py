from flask import Flask  #Flask is a web designing module similar to Django
from flask import render_template, request
import RPi.GPIO as IO
import time

app = Flask(__name__)

motor1A = 18
motor1B = 23
motor2A = 24
motor2B = 25

IO.setwarnings(False)
IO.setmode(IO.BCM)
IO.setup(motor1A, IO.OUT)
IO.setup(motor1B, IO.OUT)
IO.setup(motor2A, IO.OUT)
IO.setup(motor2B, IO.OUT)

IO.output(motor1A,False)
IO.output(motor1B,False)
IO.output(motor2A ,False)
IO.output(motor2B,False)

print("Done")
a = 1

@app.route("/")
def index():
    return render_template("robot.html")

@app.route("/left_side")
def left_side():
    data1 = "LEFT"
    IO.output(motor1A,False)
    IO.output(motor1B,False)
    IO.output(motor2A ,True)
    IO.output(motor2B,False)
    return 'true'

@app.route("/right_side")
def right_side():
    data1 = "RIGHT"
    IO.output(motor1A,True)
    IO.output(motor1B,False)
    IO.output(motor2A ,False)
    IO.output(motor2B,False)
    return 'true'

@app.route("/up_side")
def up_side():
    data1 = "FORWARD"
    IO.output(motor1A,True)
    IO.output(motor1B,False)
    IO.output(motor2A ,True)
    IO.output(motor2B,False)
    return 'true'

@app.route("/down_side")
def down_side():
    data1 = "BACK"
    IO.output(motor1A,False)
    IO.output(motor1B,True)
    IO.output(motor2A,True)
    IO.output(motor2B,True)
    return 'true'

@app.rout("/stop")
def stop():
    data1 = "STOP"
    IO.output(motor1A,False)
    IO.output(motor1B,False)
    IO.output(motor2A,False)
    IO.output(motor2B,False)
    return 'true'

if __name__ == "__main__":
    print("Start!")
    app.run(host='0.0.0.0',port=5010)
