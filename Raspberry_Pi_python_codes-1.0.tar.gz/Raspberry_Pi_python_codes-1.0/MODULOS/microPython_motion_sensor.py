from machine import Pin
from utime import sleep

led = Pin(28, Pin.OUT)
pir = Pin(16, Pin.IN, Pin.PULL_UP)
led.low()
sleep(3)

while True:
    reading = pir.value()
    print(reading)
    if reading == 0:
        print("MOTION DETECTED")
        print("LED ON")
        led.high()
        sleep(5)
    else:
        print("Waiting for motion")
        led.low()
        sleep(0.2)
