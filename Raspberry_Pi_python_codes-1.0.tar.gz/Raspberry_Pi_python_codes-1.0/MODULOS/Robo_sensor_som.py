from MotorDC import *
from soundSensor import *
from Leds import *
import tkinter as tk

sensor = soundSensor(5,"INPUT")
sensor.digitalWrite()

rightMotor = MotorDC(7,9,120)
rightMotor.info()

leftMotor = MotorDC(10,12,120)
leftMotor.info()

dioda = Leds(6)

def som():
    print("\n")
    print("*=" * 20)
    sensor.digitalRead(0)
    print("\nrightMotor:"), rightMotor.forward()
    print("\nleftMotor:"), leftMotor.forward()
    dioda.digitalRead()
    dioda.digitalWrite("HIGH")
    print("O robo estah em movimento")
    dioda.piscaLento(1000)
    print("*=" * 20)
    
def mostra():
    print("\n")
    print("*=" * 20)
    sensor.digitalRead(0)
    sensor.digitalRead(0)
    sensor.digitalRead(0)
    sensor.digitalRead(0)
    print("QUANTO BARULHO!")

    dioda.digitalRead()
    dioda.digitalWrite("HIGH")
    dioda.piscaRapido(200)
    print("\nrightMotor:"),
    rightMotor.backward()
    rightMotor.left()
    print("\nlefttMotor:"),
    leftMotor.backward()
    leftMotor.left()
    dioda.piscaRapido(200)
    print("O robo desviou pela esquerda")
    print("*=" * 20)
    
def muda():
    print("\n")
    print("*=" * 20)
    sensor.digitalRead(1)
    dioda.digitalWrite("HIGH")
    dioda.piscaLento(1200)
    print("\nrightMotor:"),
    rightMotor.stop()
    print("\nleftMotor:"),
    leftMotor.stop()
    dioda.digitalWrite("LOW")
    print("O robo parou")
    print("*=" * 20)
    
window = tk.Tk()

info = tk.Label(window, text="SENSOR DE SOM", bg="orange", fg="blue", font=("Comic Sans MS", 15))
botao1 = tk.Button(window, text="valor 0", command=som, bg="forestgreen", fg="yellow", font=("Comic Sans MS", 15))
botao2 = tk.Button(window, text="valor +1", command=mostra, bg="gold", fg="red", font=("Comic Sans MS", 15))
botao3 = tk.Button(window, text="valor 1", command=muda, bg="firebrick2", fg="ghost white", font=("Comic Sans MS", 15))

info.grid(row=1, column=1, padx=5, pady=10)
botao1.grid(row=2, column=0, padx=5, pady=10)
botao2.grid(row=2, column=1, padx=5, pady=10)
botao3.grid(row=2, column=2, padx=5, pady=10)

window.mainloop()


    
    
