from pyfirmata2 import Arduino

#instead of "sleep" function we use here a samplingOn function
#which already contains the iterator, by default it comes with a
#19 millis interval, and the smallest one is 10 millis

uno = Arduino(Arduino.AUTODETECT)

# or it if fails:
# uno = Arduino("COM....")

uno.samplingON(10)
#insert a samplingInterval in ms

#to process analog data at a given sampling interval
#register a callback handler and then enable it
uno.analog[0].register_callback(myCallback)
uno.analog[0].enable_reporting()
uno.analog[0].read()  

uno.analog[1].enable_reporting()
uno.analog[1].read()

#other option

analog_0 = uno.get_pin("a:0:i")  #instead of analog_0 I can write any name
analog_0.enable_reporting()    #for example "ultrasoundSensor" instead
analog_0.read()

pin3 = uno.get_pin("d:3:p") # for pwm
pin3.write(0.6)

analog_2 = umo.get_pin("a:2:o")
analog_2.enable_reporting()
analog_2.read()

#to finish
uno.exit()
