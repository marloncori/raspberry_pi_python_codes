from pyfirmata import Arduino, util
from time import sleep

if __name__ == "__main__":
    board = Arduino("COM8")
    print("Communication has started")

    button = board.digital[5]
    led1 = board.digital[9]
    led2 = board.digital[10]
    led3 = board.digital[11]
    led4 = board.digital[12]

    leds = [led1, led2, led3, led4]
    led_index = 0
    previous_button_state = 0 # or previous_button_state = False

    iterator = Iterator(board)
    iterator.start()

    button.mode = INPUT

    for led in leds:
        led.write(0) # led.write(False), led.write(LOW)

    while True:
        sleep(0.01)

        button_state = button.read()

        if button_state != previous_button_state:
            if button_state == 0:
                print("Button released")
                #power off current led and power on next one
                leds[led_index].write(0)
                led_index += 1

                if led_index >= len(leds):
                    led_index = 0
                leds[led_index].write(1)
        #save current button state as previous
        previous_button_state = button_state
