#exemplo de como se usa outro material como modulo, que eh termo pra biblioteca
from Robot import *

meuRobo=Robot(True,11,22,55,False)
print("\n")

meuRobo2=Robot(True,23,3,5,False)
meuRobo2.praFrente()
print("\n")

meuRobo3=Robot(True,1,24,21,True)
meuRobo3.virarDirEsq()
print("\n")

#o asterisco eh usado para importar todos os metodos do arquivo modulo
#se eu nao usar o asterisco com import, sou obrigado a usar o no nome do
#arquivo com . (ponto) diante de cada metodo, p.ex. Robot.praFrente()
