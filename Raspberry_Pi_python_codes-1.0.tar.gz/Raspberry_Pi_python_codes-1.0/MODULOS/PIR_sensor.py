from pyfirmata2 import Arduino, util
from MotorDC import *
from time import sleep

rightMotor = MotorDC(11,12,200)
leftMotor = MotorDC(7,8,200)

uno = Arduino("COM6") 
uno.get_pin("d:9:i")
thread = util.Iterator(uno)
thread.start()

sleep(1)

while True:
    if uno.digital[9].read() == True:
        print("Motion detected!!!")
        rightMotor.forward()
        leftMotor.forward()
    else:
        print("No motion")
        sleep(0.5)
