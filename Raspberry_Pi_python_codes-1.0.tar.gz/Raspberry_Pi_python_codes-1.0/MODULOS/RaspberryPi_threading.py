
#timing loop is recommended when you do not know threading, threads can make
#for more modular and encapsulated code, they are simpler for more loops

import time

def run(self):
    while not self.stopped():
        self.updateWeather()
        time.sleep(60*60)
    self.cleanup()
