from pyfirmata import Arduino, util
from time import sleep

if __name__ == "__main__":
    arduino = Arduino("COM4")
    print("Communication has started")

while True:
    arduino.digital[13].write(1) # arduino.digital[13].write(HIGH)
                                    #arduino.digital[13].write(True)
    sleep(1)
    arduino.digital[13].write(0)
    sleep(1)

    
