from machine import Pin
from utime import sleep, sleep_us

trigger = Pin(3, Pin.OUT)
echo = Pin(2, Pin.IN)

del getDistance():
    trigger.low()
    sleep_us(2)
    trigger.high()
    sleep_us(5)    #or sleep_us(10)
    tigger.low()

    sensorReading = echo.value()
    while sensorReading == 0:
        signalOFF = utime.ticks_us()  #contador de tempo

    while sensorReading == 1:
        signalON = utime.ticks_us()

    elapsedTime = signalON - signalOFF  # sound speed 0.0343 cm/us
    distance = (elapsedTime * 0.0343)/2  # sound speed = 343.2 m/s

    print("The distance from the object is ",distance,"cm")

while True:
    getDistance()
    sleep(1)

        
