
class Leds():
    def __init__(self,pin):
        self.pin=pin
        
    def digitalRead(self):
        print("\n\tdigitalRead(",self.pin,",OUTPUT)")
        
    def digitalWrite(self,state):
        self.state=state
        if state == "HIGH":
            self.__acende()
        elif state == "LOW":
            self.__apaga()
            
    def __acende(self):
        print("\tO led acendeu!")
        
    def __apaga(self):
        print("\tO led apagou!")
        
    def piscaRapido(self,delay):
        self.delay=delay
        if self.state == "HIGH":
            print("\tO led esta piscando rapido.")
        else:
            print("\tO led nao tem como piscar!")
        if delay > 500:
            print("\tInforme um tempo em milesimos de segundos mais baixo.")
            
    def piscaLento(self,delay2):
        self.delay2=delay2
        if self.state == "HIGH":
            print("\tO led esta piscando devagar.")
        else:
            print("\tNao da pro led piscar agora!")

dioda = Leds(6)
dioda.digitalWrite("LOW")
dioda.piscaLento
