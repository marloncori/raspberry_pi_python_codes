from pyfirmata2 import Arduino, util, SERVO
from time import sleep

uno = Arduno("COM4")
it = util.Iterator(uno)
it.start()

servo = uno.get_pin("d:12:o")
uno.digital[12].mode = SERVO

servo2 = uno.get_pin("d:10:o")
uno.digital[10].mode = SERVO

while True:
    angle = int(input("Enter an angle lower than 180: ")
    servo.write(angle)

    for c in range(0,180,10):
        servo2.write(c)
    for d in range(180,0,20):
        servo2.write(d)
