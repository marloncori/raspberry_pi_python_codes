import time                               # from time import sleep
import machine                            # from machine import Pin
                                          #
blueled = machine.Pin(2, machine.Pin.OUT) # blueled = Pin(2,Pin.OUT)

for c in range(1,11):       
    blueled.value(0)
    time.sleep(0.5)                      # sleep(0.5)
    blueled.value(1)
    time.sleep(0.5)                      # sleep(0.5)

print("Done!")
