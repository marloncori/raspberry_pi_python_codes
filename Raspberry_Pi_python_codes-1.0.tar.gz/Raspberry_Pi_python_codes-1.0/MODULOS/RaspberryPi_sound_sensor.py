import RPi.GPIO as IO
import time

channel = 17 # sound sensor RPi Pin
IO.setmode(IO.BCM)
IO.setup(channel, GPIO.IN)

def callback(channel):
    reading = IO.input(channel)
    if reading:
        print("Sound detected!")

    else:
        print("No sound detected")

IO.add_event_detect(channel, IO.BOTH, bouncetime=300)
IO.add_event_callback(channel, callback) # asign fuction to GIO PIN
                                        #and run it on state change

while True:
    time.sleep(1)
