#sound sensor to control Phillips Hue lights

from time import sleep
import RPi.GPIO as IO
from qhue import Bridge

IO.setmode(IO.BOARD) # use board pin numbers, not BCM
pin = 7
IO.setup(pin,IO.IN)

qHue = Bridge("192.168.1.30", "e254339152304b714add57d14a8fdbb")
groups = qHue.groups

while True:
    if IO.input(pin) == IO.LOW:
        i = 3 # iterations
        for l in range(1,i+1)
        #temporary effect, offical docs
        # at http://www.developers.meethue.com/documentation/core-concepts
        qHue.groups[0].action(alert="select") # group zero - all lights
        sleep(1)
    sleep(10)
