import sys

sys.setrecursionlimit(20)
threshold = sys.getrecursionlimit()

print("limit = ", threshold)

i = 0

def greet():
    global i
    while i <= 20:
        i+=1
        print("\nHello, great ", i)
        greet()
    
greet()
