from machine import Pin
import utime

led = Pin(16, Pin.OUT)
IR_sensor = Pin(15, Pin.IN)

while True:
    reading = IR_sensor.value()
    print(reading)
    if reading == 1:  #sensor emits a HIGH signal, no obstacle has been detected
        led.value(0)

    else:
        led.value(1)  #turn on the LED when sensor emits a LOW signal
                        #which means an obstacle has been detected
