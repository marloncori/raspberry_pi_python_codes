from pyfirmata2 import Arduino, util
from adafruit_hcsr04 import HCSR04
from time import sleep

arduinoUno = Arduino("COM4")
it = util.Iterator(arduinoUno)
it.start()

trigPin = arduinoUno.get_pin("a:5:o")
arduinoUNO.analong[5].mode = HCSR04

echoPin = arduinoUno.get_pin("a:6:o")
arduinoUNO.analong[6].mode = HCSR04

sonar = HCSR04(trigger_pin=arduinoUno.A5, echo_pin=arduinoUno.A6)

while True:
    sonar.distance = arduinoUno.analog[6].read()
    try:
        print((sonar.distance))
    except RunTimeError:
        print("Retrying!")
        time.sleep(2)
