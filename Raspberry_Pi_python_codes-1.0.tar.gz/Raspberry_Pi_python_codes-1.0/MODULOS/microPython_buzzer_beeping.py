from machine import Pin, PWM
from utime import sleep

buzer = PWM(Pin(15))
buzzer.freq(500)

#Set the duty_u16 property of the buzzer object to 1000.
#This makes the buzzer as loud as it can be. A lower value is quiet
buzzer.duty_u16(1000)

sleep(1)
buzzer.duty_u16(0)
