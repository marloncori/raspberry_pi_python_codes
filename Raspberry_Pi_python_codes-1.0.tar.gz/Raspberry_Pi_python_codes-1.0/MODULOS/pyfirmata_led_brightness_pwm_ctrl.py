from pyfirmata import Arduino, util
from time import sleep

if __name__ == "__main__":
    uno = Arduino("COM9")
    print("Communication has started")

    led = uno.digital[9]
    led.mode = PWM

    pwm_ctr = 0.01
    increase_pwm = True

    while True:
        if increase_pwm:
            pwm_ctr += 0.01
            if pwm_ctr >= 1:
                increase_pwm = False

        else:
            pwm_ctr -= 0.01
            if pwm_ctr <= 0:
                increase_pwm = True

        led.write(pwm_ctr)
        sleep(0.01)
