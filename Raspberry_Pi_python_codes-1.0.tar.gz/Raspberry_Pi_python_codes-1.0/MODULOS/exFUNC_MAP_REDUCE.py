from functools import reduce

event = [45,25,69,81]

doubles = list(map(lambda n : n*2,event))
print("doubles = ", doubles)

soma = reduce(lambda a,b : a+b, doubles)
print("\nsoma = ", soma)
