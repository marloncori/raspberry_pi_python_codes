from Carros import*
import os

carros=[] #lista de carros criados no menu, usando a classe class Carro

def Menu():
    os.system("cls") or None
    print("*=" * 22)
    print("\tMENU DE AUTOMOVEIS ")
    print("*=" * 22)
    print("\t1. Novo carro")
    print("\t2. Informacoes do carro")
    print("\t3. Excluir carro")
    print("\t4. Ligar carro")
    print("\t5. Desligar carro")
    print("\t6. Listar carro")
    print("\t7. Sair")
    print("\t  Qtd. de carros: " +str(len(carros)))
    opc=input("\n\tDigite uma opcao: ")
    return opc             #tenho que verificar se o que foi digitado esta
    print("*=" * 22)       #dentro do menu
    print(" ")
    print("*=" * 22)
    
    
def novoCarro():
    os.system("cls") or None
    
    name=input("Nome do carro........: ")
    power=input("Potencia do carro...: ")
    car=Carro(name,power) #depois de criado, anexo o carro aa lista
    carros.append(car)    #metodo para adicionar membro a lista
    print("Novo carro criado com sucesso")

    os.system("pause")

def informacoes():
    os.system("cls") or None
    num=input("Informe o numero do carro cujas informacoes deseja ver: ")

    try: #precisa verificar se vai aparecer algum erro com a try...catch
        carros[int(num-)].info()
    except: #geramos uma excexcao se o carro nao existir
        print("Esse carro nao exite na lista")
    os.system("pause")

def excluir():
    os.system("cls") or None
    pos=input("Informe o numero do carro que deseja excluir: ")

    try: #precisa verificar se vai aparecer algum erro com a try...catch 
       del carros[int(pos)]
    except:
        print("Carro nao estah na lista")
    os.system("pause")

def ligarCarro():
    os.system("cls") or None
    n=input("Informe o numero do carro que deseja ligar: ")
    try:
        carros[int(n)].ligar()
    except:
        print("Carro nao estah na lista")
    os.system("pause")
    
def desligarCarro():
    os.system("cls") or None
    nm=input("Informe o numero do carro que deseja desligar: ")
    try:
        carros[int(nm)].desligar()
    except:
        print("Carro nao estah na lista")
    os.system("pause")        

def listarCarro():
    os.system("cls") or None
    p=0
    for c in carros:                    #tem que percorrer a lista carros[]
        print(str(p+1) + " - " + c.nome)
        p=p+1
    os.system("pause")

feedback=Menu()  #o que eu digitar no menu ficara armazenado em feedback
while feedback < "7":
    if feedback == "1":
        novoCarro()
    elif feedback == "2":
        informacoes()
    elif feedback == "3":
        excluir()
    elif feedback == "4":
        ligarCarro()
    elif feedback == "5":
        desligarCarro()
    elif feedback == "6": 
        listarCarro()
    else:
        print("Opcao invalida. Tente de novo.")
    feedback=Menu()

os.system("cls") or None
print("\tPrograma finalizado com sucesso.")
