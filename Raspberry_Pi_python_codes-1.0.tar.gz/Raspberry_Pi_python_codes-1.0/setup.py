from setuptools import setup

setup(

    name="Raspberry_Pi_python_codes",
    version="1.0",
    description="several python codes for Raspberry Pi 3, Zero W and Pico",
    author="Marlon Couto Ribeiro",
    author_email="yuelami@gmail.com",
    url="www.sekretypoliglotow.pl",
    packages=["MODULOS"]
    
    )
